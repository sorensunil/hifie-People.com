# HiFiPeople — Free Static Hosting Package

This package is prepared for static hosting services such as GitHub Pages, Cloudflare Pages, and Netlify.

## Important
- `index.html` is the website entry point.
- All HTML pages use relative local links.
- No PHP, Node.js, database, or server is required for the pages to load.
- The current admin/member controls are front-end HTML/JavaScript features. They are not a secure production backend.

## GitHub Pages
1. Create a GitHub repository.
2. Upload all files from this folder to the repository root.
3. Open Settings → Pages.
4. Choose "Deploy from a branch".
5. Select the main branch and `/ (root)`.
6. Save and open the generated GitHub Pages address.

## Cloudflare Pages
1. Create a Pages project.
2. Connect the repository or upload the project files.
3. For a plain static site, no build command is required.
4. Use the generated `pages.dev` address.

## Netlify
1. Create a new site.
2. Deploy the folder containing `index.html` and the other files.
3. Use the generated `netlify.app` address.

## Production warning
Do not treat the HTML admin panel as real security. For real member accounts, passwords, roles, points, moderation, messages, notifications, and admin permissions, connect the site to a secure backend/database and server-side authentication.


## New Owner Admin Panel
Open `admin-panel.html` for the separate owner command center with user management, roles, moderation, reports, notifications, analytics, security, audit logs, system settings and power tools.


## Demo flow
Open `demo.html` first. It links to the public website, demo login, members, and the separate Owner Admin Panel.

Demo login is front-end only; connect a real authentication/database backend before production use.
