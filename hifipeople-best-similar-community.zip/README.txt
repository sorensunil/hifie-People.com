HiFiPeople Best Community Site
===============================
This build is a polished static community front-end inspired by the requested HiFiPeople concept.
Included:
- Community home/feed
- Search UI
- Members, messages, notifications, profile, communities, events, saved pages
- Create-post demo interaction
- Responsive desktop/mobile layout
- Separate Owner Admin page retained from the uploaded project
- Clean navigation between pages

Run:
1. Extract the ZIP.
2. Open index.html in a browser, or run:
   python -m http.server 8000
3. Visit http://127.0.0.1:8000/index.html
4. Owner panel: http://127.0.0.1:8000/admin.html

This is a static front-end demo. Real accounts, database persistence, authentication,
server-side permissions, moderation enforcement and secure owner-only controls require a backend.
