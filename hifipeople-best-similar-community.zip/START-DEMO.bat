@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed.
  echo Open demo.html directly in Chrome instead.
  pause
  exit /b
)
echo Starting HiFiPeople demo server...
start "HiFiPeople Demo" http://127.0.0.1:8000/demo.html
python -m http.server 8000
